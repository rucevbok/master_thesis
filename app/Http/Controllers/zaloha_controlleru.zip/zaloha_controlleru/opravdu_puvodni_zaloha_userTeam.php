<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class userTeamController extends Controller
{

    public function index()
    {
        return "s";
    	$uziv_proj = \App\UserTeam::all();
    	$uzivatele = \App\User::all();
    	$uz=collect(DB::select('SELECT projekt.idproj, projekt.nazev, projekt.popis, users.name,users.email, projekty_a_clenove.role  FROM projekty_a_clenove INNER JOIN users ON projekty_a_clenove.login=users.email INNER JOIN projekt ON projekty_a_clenove.idproj=projekt.idproj ORDER BY projekt.idproj,projekty_a_clenove.role '));

    	$vsichni_users = \App\User::all()->where('role','user');
    	$projektaci = \App\User::all()->where('role','projmanazer');
    	$katalog = \App\Katalog::all();
    	$stara= "lol123T4534";

    	return view ('projekt_clenove2',compact('uz','vsichni_users','projektaci','katalog','stara'));
    }

    public function save()
    {
    	
		$proj = new \App\Project;
        $proj->nazev = request()->nazev;
		$proj->popis = request()->popis;
        $proj->save();
        $id_projektu = $proj->id;

        $row = new \App\userTeam;
   		$row->idproj = $id_projektu;
    	$row->login = request()->role;
    	$row->role = 'projmanazer';
    	$row->save();

        $row = new \App\SWOT;
        $row->idproj = $id_projektu;
        $row->strengths = '';
        $row->weak = '';
        $row->opport = '';
        $row->threats = '';
        $row->save();


        if(request()->filled('clenove'))
        {
        $clenove = request()->clenove;
        foreach ($clenove as $clen) {
        	$row = new \App\userTeam;
       		$row->idproj = $id_projektu;
        	$row->login = $clen;
        	
        	$row->role = 'user';
        	$row->save();
        }
        }
        
		$zvolene_atributy = request('result');
        
    	foreach( $zvolene_atributy as $atri) {
            $polozka_sabl = new \App\PolozkySablony();
           	$polozka_sabl->idproj = $id_projektu;
           	$polozka_sabl->atribut = $atri;
           	$polozka_sabl->save();
         }
        
    	return redirect()->route('uzivatel_tym');
    }

    public function destroy()
    {	

   		DB::table('users')->where('email', request()->smazanej)->delete();
        return redirect()->route('vytvorit_uz');
    	
    }

    public function insert_zero()
    {
		$clenove = \App\User::all()->where('role','user');
    	$projekty = \App\Project::all();
    	return view('pridat_clena_tymu',compact('clenove','projekty'));
    }

    public function insert_one()
    {
    	
    	$clenove = \App\User::all()->where('role','user');
    	$this->clen_sel = request()->clen;
    	$clen_name =\App\User::all()->where('email',request()->clen)->pluck('name')->first();
        $clen_sel = request()->clen;
        $pero = \App\Project::all();
    	$projekty = \App\Project::all()->pluck('idproj');
    	$projekty_clena = \App\UserTeam::all()->where('login',$this->clen_sel)->pluck('idproj');
    	$vysledek = $projekty->diff($projekty_clena)->values();
    	$vysledek_projekty = $pero -> whereIn('idproj',$vysledek);
    	return view ('pridat_clena_tymu2',compact('vysledek_projekty','clenove','clen_name','clen_sel'));
    	//return $vysledek_projekty;
    }
    public function insert_two()
    {
  
		$row = new \App\userTeam;
   		$row->idproj = request()->projekt;
    	$row->login = request()->id_clena;
    	$row->role = 'user';
    	$row->save();
    	$clenove = \App\User::all()->where('role','user');
    	$this->clen_sel = request()->clen;
    	$clen_sel =request()->clen;
    	$pero = \App\Project::all();
    	$projekty = \App\Project::all()->pluck('idproj');
    	$projekty_clena = \App\UserTeam::all()->where('login',$this->clen_sel)->pluck('idproj');
    	$vysledek = $projekty->diff($projekty_clena)->values();
    	$vysledek_projekty = $pero -> whereIn('idproj',$vysledek);
    	return view ('pridat_clena_tymu3',compact('clenove','clen_sel','vysledek_projekty'));
    }

}












